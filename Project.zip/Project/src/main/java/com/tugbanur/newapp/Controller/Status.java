package com.tugbanur.newapp.Controller;

public enum Status {
        SUCCESS,
        USER_ALREADY_EXISTS,
        FAILURE

}
