package com.tugbanur.newapp.Service;

import com.tugbanur.newapp.Entity.User;
import org.springframework.stereotype.Service;


@Service("userService")
public interface UserService {

    void save(User user);

    User findByUsername(String username);
}
