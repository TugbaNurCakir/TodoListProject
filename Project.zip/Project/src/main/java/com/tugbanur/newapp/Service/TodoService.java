package com.tugbanur.newapp.Service;

import com.tugbanur.newapp.Entity.Todo;
import org.springframework.stereotype.Service;

@Service
public interface TodoService {
    void add(Todo todo);

    void update(Todo note);

    void delete(Todo note);

}
