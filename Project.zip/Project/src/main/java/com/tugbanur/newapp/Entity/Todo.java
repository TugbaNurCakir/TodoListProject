package com.tugbanur.newapp.Entity;

import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.NoArgsConstructor;

@NoArgsConstructor //this annotation adds non arguments constructor by automatically
@Data //this annotation adds getter and setter by automatically
@Entity
@Table(name = "todos")
public class Todo {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @NotEmpty
    @NotNull
    private Long id;

    @Column
    @NotEmpty
    @NotNull
    private String description;

    @Column
    @NotEmpty
    @NotNull
    private Boolean is_completed = Boolean.FALSE;

    public Todo(Long id, String description, Boolean is_completed) {
        super();
        this.id = id;
        this.description = description;
        this.is_completed = false;
    }

    public Todo(String todoDescription) {
        this.description = todoDescription;
    }

    @Override
    public String toString() {
        return "Todo{" +
                "id=" + id +
                ", description='" + description + '\'' +
                ", is_completed=" + is_completed +
                '}';
    }
}
