package com.tugbanur.todoappproject.controller;
import com.tugbanur.todoappproject.request.AddTodoRequest;
import com.tugbanur.todoappproject.request.AddUserRequest;
import com.tugbanur.todoappproject.entity.Todo;
import com.tugbanur.todoappproject.entity.User;
import com.tugbanur.todoappproject.repository.TodoRepository;
import com.tugbanur.todoappproject.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

import java.util.NoSuchElementException;

@RestController
@RequestMapping("/users")
public class UserController {
    private UserRepository userRepository;
    private TodoRepository todoRepository;

    public UserController() {
        this.userRepository = userRepository;
        this.todoRepository = todoRepository;
    }

    @GetMapping("/{userId}")
    public ResponseEntity<User> getUserById(@PathVariable Long userId){
        User user = userRepository.findById(userId).orElseThrow(()->new NoSuchElementException());
        return new ResponseEntity<>(user, HttpStatus.OK);
    }
    @PostMapping("/addUser")
    public ResponseEntity<User> addUser(@RequestBody AddUserRequest userRequest){
        User user = new User();
        user.setUsername(userRequest.getUsername());
        user.setPassword(userRequest.getPassword());
        return new ResponseEntity<>(user, HttpStatus.CREATED);
    }
    @PostMapping("/{userId}/addTodo")
    public ResponseEntity<Todo> addTodo(@PathVariable Long userId, @RequestBody AddTodoRequest todoRequest){
        User user = userRepository.findById(userId).orElseThrow(()->new NoSuchElementException());
        Todo todo = new Todo();
        todo.setContent(todoRequest.getContent());
        user.getTodoList().add(todo);
        todoRepository.save(todo);
        return new ResponseEntity<>(todo, HttpStatus.CREATED);
    }
    @PostMapping("{todos}/todoId")
    public ResponseEntity<Todo> todoCompleted(@PathVariable Long todoId){
        Todo todo = todoRepository.findById(todoId).orElseThrow(()->new NoSuchElementException());
        todo.setIsCompleted(!todo.getIsCompleted());
        todoRepository.save(todo);
        return new ResponseEntity<>(todo, HttpStatus.CHECKPOINT);
    }
    /*
    @PostMapping("{todos}/todoId")
    public void toggletodoCompleted(@PathVariable Long todoId){
        Todo todo = todoRepository.findById(todoId).orElseThrow(()->new NoSuchElementException());
        todo.setCompleted(!todo.getCompleted());
        todoRepository.save(todo);
    }
    */
    @DeleteMapping("/delete/{userId}")
    public ResponseEntity<User> deleteUser(@PathVariable Long userId){
        User user = userRepository.findById(userId).orElseThrow(()->new NoSuchElementException());
        userRepository.delete(user);
        return new ResponseEntity<>(user, HttpStatus.OK);
    }
    @DeleteMapping("/delete/{userId}/deleteTodo/{todoId}")
    public ResponseEntity<Todo> deleteTodo(@PathVariable Long todoId, @PathVariable Long userId){
        User user = userRepository.findById(userId).orElseThrow(()->new NoSuchElementException());
        Todo todo = todoRepository.findById(todoId).orElseThrow(()->new NoSuchElementException());
        user.getTodoList().remove(todo);
        todoRepository.delete(todo);
        return new ResponseEntity<>(todo, HttpStatus.OK);
    }
    /*
    @DeleteMapping("/{userId}/deleteTodo/{todoId}")
    public void deleteTodo(@PathVariable Long todoId, @PathVariable Long userId){
        User user = userRepository.findById(userId).orElseThrow(()->new NoSuchElementException());
        Todo todo = todoRepository.findById(todoId).orElseThrow(()->new NoSuchElementException());
        user.getTodoList().remove(todo);
        todoRepository.delete(todo);
    }
     */
}
