package com.tugbanur.newapp.Repository;

import com.tugbanur.newapp.Entity.User_Todo_List;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface User_Todo_List_Repository extends PagingAndSortingRepository<User_Todo_List, Long> {


}