package com.tugbanur.newapp;
import com.tugbanur.newapp.Repository.TodoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;

@Configuration
@SpringBootApplication
public class NewappApplication implements CommandLineRunner {
    @Autowired
    public TodoRepository todoRepository;
    public static void main(String[] args) {
        SpringApplication.run(NewappApplication.class, args);
    }


    @Override
    public void run(String... args) throws Exception {

    }
}
