package com.tugbanur.newapp.Controller;


import com.tugbanur.newapp.Entity.Todo;
import com.tugbanur.newapp.Entity.User_Todo_List;
import com.tugbanur.newapp.Repository.TodoRepository;
import com.tugbanur.newapp.Repository.User_Todo_List_Repository;
import com.tugbanur.newapp.Service.TodoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
public class TodoController implements TodoService {

    private TodoRepository todoRepository;
    private User_Todo_List_Repository user_todo_list_repository;

    @Autowired
    public TodoController(TodoRepository todoRepository, User_Todo_List_Repository user_todo_list_repository) {
        this.user_todo_list_repository = user_todo_list_repository;
        this.todoRepository = todoRepository;
    }
//@RequestParam(required = true) String todoDescription, Long userId

@RequestMapping(value = "/todo/addTodo", method = RequestMethod.GET, produces= MediaType.APPLICATION_JSON_VALUE)
public void addTodo(@RequestParam(required = true) String todoDescription) {

    System.out.println("Im working fine: " + todoDescription);

    try{
        Todo todo = new Todo();
        todo.setDescription(todoDescription);
        todoRepository.save(todo); //Save todo list
         User_Todo_List userTodoList = new User_Todo_List();
         userTodoList.setTodo_id(todo.getId());
         userTodoList.setUser_id(1L);
         userTodoList.setId((long) Math.random());
         System.out.println("Go fine");
         user_todo_list_repository.save(userTodoList); //Save user todo list
        System.out.println("Everything seems fine");
    }catch(Exception e){
        System.out.println("We have an exceptionnnnnn");
        System.out.println(e.toString());
    }

}

    @Override
    public void add(Todo todo) {

    }

    @PutMapping("/update")
    public void update(@RequestBody Todo todo) {
        this.todoRepository.save(todo);
    }

    @Override
    @DeleteMapping("/delete")
    public void delete(Todo todo) {
        this.todoRepository.delete(todo);
    }

}
