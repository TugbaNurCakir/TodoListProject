package com.tugbanur.newapp.Entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.UUID;

@NoArgsConstructor  //this annotation adds non arguments constructor by automatically
@Data  //this annotation adds getter and setter by automatically
@Entity
@Table(name = "user_todo_list")
public class User_Todo_List {
    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column
    private Long user_id;
    @Column
    private Long todo_id;



    public User_Todo_List(Long id, Long user_id, Long todo_id) {
        super();
        this.id = id;
        this.user_id = user_id;
        this.todo_id = todo_id;
    }

    @Override
    public String toString() {
        return "User_Todo_List{" +
                "id=" + id +
                ", user_id=" + user_id +
                ", todo_id=" + todo_id +
                '}';
    }
}
