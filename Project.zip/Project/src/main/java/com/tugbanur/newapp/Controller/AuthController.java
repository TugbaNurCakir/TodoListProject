package com.tugbanur.newapp.Controller;

import com.tugbanur.newapp.Entity.User;
import com.tugbanur.newapp.Repository.UserRepository;
import com.tugbanur.newapp.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;

@RestController
public class AuthController implements ErrorController {
    private UserService userService = new UserService() {
        @Override
        public void save(User user) {
        }
        @Override
        public User findByUsername(String username) {
            return null;
        }
    };
    @Autowired
    private UserRepository userRepository;

    private static final String PATH = "/error";
/*
    @RequestMapping(value = PATH)
    public String error() {
        return "Error handling";
    }
*/
    public AuthController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public String getErrorPath() {
        return PATH;
    }

    // produces= MediaType.APPLICATION_JSON_VALUE

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public HashMap<String, Object>  login(@RequestParam(required = true) String userName, String password){
        User user = userRepository.findByUsername(userName);
        if(user.getUsername().equals(userName) && user.getPassword().equals(password)){
            HashMap<String, Object> map = new HashMap<String, Object>();
            map.put("isSuccess", true);
            return map;
        }
        else{
            HashMap<String, Object> map = new HashMap<String, Object>();
            map.put("isSuccess", false);
            return map;
        }
    }


    @RequestMapping(value = "/register", method = RequestMethod.GET, produces= MediaType.APPLICATION_JSON_VALUE)
    public HashMap<String, Object> register(@RequestParam(required = true) String userName, String password) {
        User user = new User();
        user.setUsername(userName);
        user.setPassword(password);
        User registration = userRepository.save(user);
        Long userId = registration.getId();
        if(userId>=1){
            HashMap<String, Object> map = new HashMap<String, Object>();
            map.put("isSuccess", true);
            return map;
        }
        else{
            HashMap<String, Object> map = new HashMap<String, Object>();
            map.put("isSuccess", false);
            return map;
        }
    }


 }
