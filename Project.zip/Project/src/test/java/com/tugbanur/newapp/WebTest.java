package com.tugbanur.newapp;

import static org.assertj.core.api.Assertions.assertThat;
import com.tugbanur.newapp.Controller.TodoController;
import javafx.beans.binding.Bindings;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.hamcrest.MatcherAssert.assertThat;

@SpringBootTest
public class WebTest {
    @Autowired
    private TodoController todoController;

    @Test
    public void contextLoads() throws Exception {
        assertThat(todoController).isNotNull();
    }


}
