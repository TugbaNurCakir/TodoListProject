package com.tugbanur.newapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewappApplicationTests {

    @Test
    void contextLoads() {
    }

}
